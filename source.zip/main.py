import os, discord, keep_alive
from discord.ext import commands
from os import listdir
import aiohttp

prefixes = ['-', '//', '_']

bot = commands.Bot(command_prefix = prefixes,case_insensitive = True, intents = discord.Intents.all())

@bot.event
async def on_ready():
	print('Logged in')
	print("I'm online and working")
	for i in range(10000):
	    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="You"))

@bot.command()
async def login(ctx):
	devs = ['775198018441838642', '750755612505407530', '746904488396324864']
	if str(ctx.author.id) not in devs:
		await ctx.reply(f'Only **The Devs** can log me in.\nCurrent Devs are <@{devs[0]}>, <@{devs[1]}>, <@{devs[2]}>')
		return
	embed=discord.Embed(title = "Logged In", description = f"With Latency {round(bot.latency*1000)}", color = discord.Color.red())
	await ctx.send(embed=embed)
	os.system("python all.py")




@bot.command()
async def logout(ctx):
	await ctx.send("You're already logged out dummy")


@bot.command()
async def shutdown(ctx):
	await ctx.send("Shutting down...")
	os.system("pkill -f main.py")

@bot.command()
async def jailshell(ctx):
	await ctx.send("Entering jailshell...")
	os.system("python jailshell.py")


keep_alive.keep_alive()
bot.run('ODE4MDA3NDcwMTEwMDE1NDkw.YERy0g.aKLOKoH5AQ1XU_V4gVyZvyqSdTo')

