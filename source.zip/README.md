# Welcome to Unamed bot

Unamed bot is a bot made by 3 amazing bot developers.

### Commands
```
Developer:
  login     
  logout    Logs the bot out
  ping      Gives the latency
Fun:
  8ball     Tells you your future
  coolrate  Rates how cool you/someone is
  echo      Echoes a message
  flipacoin Flips coins
  gayrate   Rates how gay you/someone is
  meme      
  simprate  Rates how simp you/someone is
Moderator:
  ban       Bans a person
  kick      Kicks a mentioned person.
  lock      Locks the channel
  mute      Mutes Someone
  role      Add/Remove a role
  unlock    Unlocks a channel
  unmute    Unmutes a muted person
Utility:
  afk       Sets an AFK for you
  purge     Purges messages
  slowmode  Toggles Slowmode
  warn      Warns a user
​No Category:
  help      Shows this message

Type -help command for more info on a command.
You can also type -help category for more info on a category.
```

### Modules
The bot comes pre-packed with modules usind discord.jpy

### Gaw module
```
Help panel
Find the list of my orders on this panel, obligatory arguments <>.
-gstart
This command is used to launch a giveaway.
Usage -gstart <#salon> <time> <winners> <lot>.
-gend
This command is used to delete a giveaway.
Usage -gend <ID giveaway>.
-greroll
This command is used to restart a giveaway.
Usage -greroll <ID giveaway>.
-gedit
This command is used to modify a giveaway.
Usage -gedit <ID giveaway> <winners> <new lot>.
-glang
This command is used to change the language of the bot.
Usage -glang <fr/en>.
-gset
This command is used to modify the bot's configurations.
Usage -gset <mention/logs/role>.
-ginvite
This command is used to get the bot's invitation link.
Usage -ginvite.
```

### Installation
```
git clone linktba
cd linktba
unpack
python -m poetry
python main.py
```

### Module Installation
```
cd modules
cd gaw(may change depending on module)
npm i
node index.js
```

### Credits
<a href="">Ace</a> - Kool kid
Kaneki - I liek exploits
Skull Crusher - Aspiring coder