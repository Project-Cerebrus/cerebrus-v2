import os, discord, keep_alive
from discord.ext import commands
from os import listdir

prefixes = ['-', '//', '_']

bot = commands.Bot(command_prefix = prefixes,case_insensitive = True, intents = discord.Intents.all())

@bot.event
async def on_ready():
	print('Logged in')
	print("I'm online and working")
	for i in range(10000):
	    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="You"))

for file in listdir('cogs/'):
    if file.endswith('.py'):
        bot.load_extension(f'cogs.{file[:-3]}')

keep_alive.keep_alive()
bot.run('ODE4MDA3NDcwMTEwMDE1NDkw.YERy0g.aKLOKoH5AQ1XU_V4gVyZvyqSdTo')

