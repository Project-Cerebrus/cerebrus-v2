print("shutdown ::1 Ace, Kaneki and Skull")
exit()