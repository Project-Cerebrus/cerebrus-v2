import discord, random
from discord.ext import commands
import aiohttp

bot = commands.Bot(command_prefix = '-')

class fun(commands.Cog, name='Fun'):
	def __init__(self, bot):
		self.bot = bot
	
	@commands.command(name='echo' , brief='Echoes a message', description='Echoes a message into a specified channel\nSyntax: //echo [channel] [message]')
	async def echo(self, ctx, channel=None,  *, msg_echo=None):
		if msg_echo is None:
			await ctx.reply('The syntax is `-echo #channel <msg>`')
			return
		if channel is None:
			await ctx.reply('The syntax is `-echo #channel <msg>`')
			return
		if str(channel).startswith('<#'):
			channelid = channel.replace('<#','')
			channelid = channelid.replace('>','')
			channel = ctx.guild.get_channel(int(channelid))
			await channel.send(str(msg_echo))
		else:
			await ctx.reply('The syntax is `-echo #channel <msg>`')

	@commands.command(name='simprate', brief = 'Rates how simp you/someone is', description = 'Rates how simp you/someone is\nSyntax //simprate [person if you want to simprate someone]')
	async def simprate(self, ctx, *, torate=None):
		if torate == None:
			torate = ctx.author.display_name
		percent = random.randrange(0,100)
		gembed = discord.Embed(title = 'SimpRate Machine', description = f"{torate} is {percent}% Simp :blush:", colour = discord.Colour.magenta())
		await ctx.send(embed=gembed)

	@commands.command(name='coolrate', brief = 'Rates how cool you/someone is', description = 'Rates how cool you/someone is\nSyntax //coolrate [person if you want to simprate someone]')
	async def coolrate(self, ctx, *, torate=None):
		if torate == None:
			torate = ctx.author.display_name
		percent = random.randrange(0,100)
		gembed = discord.Embed(title = 'CoolRate Machine', description = f"{torate} is {percent}% Cool :sunglasses:", colour = 00000)
		await ctx.send(embed=gembed)

	@commands.command(name='gayrate', brief = 'Rates how gay you/someone is', description = 'Rates how gay you/someone is\nSyntax //gayrate [person if you want to simprate someone]', aliases = ['howgay'])
	async def gayrate(self, ctx, *, torate=None):
		if torate == None:
			torate = ctx.author.display_name
		percent = random.randrange(0,100)
		gembed = discord.Embed(title = 'GayRate Machine', description = f"{torate} is {percent}% Gay :gay_pride_flag:", colour = discord.Colour.blurple())
		await ctx.send(embed=gembed)

	@commands.command(name = 'flipacoin', brief = 'Flips coins', description = 'Flips a requested number of coins and gives you the outcome', aliases = ['flipcoin', 'tosscoin', 'tossacoin'])
	async def flipacoin(self, ctx, number=None):
		if number == None:
			ans = random.choice(['Heads', 'Tails'])
			embed=discord.Embed(title = 'Flipped A Coin', description = ans, color = discord.Color.green())
			await ctx.send(embed=embed)
		else:
			number = int(number)
			answers = []
			for i in range(number):
				num = random.choice(['Heads', 'Tails'])
				answers.append(num)
			ans = str(answers)
			ans = ans.replace('[', '')
			ans = ans.replace(']', '')
			ans = ans.replace('\'', '')
			embed=discord.Embed(title = 'Outcomes', description =ans, color = discord.Color.magenta())
			await ctx.send(embed=embed)


	@commands.command(name='8ball', brief = 'Tells you your future', description = 'Tells you your future based on random choice\nSyntax //8ball [person if you want to simprate someone]', aliases = ['ask8', 'magic8'])
	async def magic_8_ball(self, ctx, *, question=None):
		random_answers = ['No Doubt', 'My sources tell me YES', 'You can rely on that', 'Better not tell you', 'Reply Hazy, Try Again', 'Nah, I wouldn\'nt keep my hopes high on that', 'Highly Doubtful', 'Hell No']
		if question == None:
			await ctx.reply('Ask a question so that i can reply to it smh')
			return
		embed=discord.Embed(description=random.choice(random_answers), colour = discord.Color.blurple())
		embed.set_author(name = question, icon_url = ctx.author.avatar_url)
		await ctx.send(embed=embed)

	@commands.command(pass_context=True)
	async def meme(self, ctx):
		a,b,c = random.randint(0,255), random.randint(0,255), random.randint(0,255)
		embed = discord.Embed(title="A Meme...", description="[Latest Memes](https://www.reddit.com/r/dankmemes/new)", colour = discord.Colour.from_rgb(a,b,c))
		async with aiohttp.ClientSession() as cs:
			async with cs.get('https://www.reddit.com/r/dankmemes/new.json?sort=hot') as r:
				res = await r.json()
				embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
			await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(fun(bot))