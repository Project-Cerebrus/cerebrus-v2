import discord, random, asyncio, difflib
from difflib import get_close_matches
from discord.ext import commands

bot = commands.Bot(command_prefix = '-')

class moderator(commands.Cog, name='Moderator'):
	def __init__(self, bot):
		self.bot = bot

	@commands.command(name='lock', brief = 'Locks the channel', description = 'Locks down the channel for the default role', aliases = ['lk', 'l'])
	async def lock(self, ctx, *, reason=None):
		if ctx.author.guild_permissions.manage_channels == True or ctx.author.guild_permissions.administrator == True:
			overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
			overwrite.send_messages = False
			await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
			x = reason
			if x == None:
				embed = discord.Embed(title = 'Channel Locked :lock:', description = f'By - {ctx.author.mention} \nReason - None Given', colour = discord.Colour.magenta())
			else:
				embed = discord.Embed(title = 'Channel Locked :lock:', description = f'By - {ctx.author.mention} \nReason - {x}', colour = discord.Colour.magenta())
			await ctx.send(embed=embed)
		else:
			await ctx.reply('You dont have permissions')

	@commands.command(name='unlock', brief = 'Unlocks a channel', description = 'Unlocks the channel for the default role', aliases = ['unlk', 'ul'])
	async def unlock(self, ctx, *, reason=None):
		if ctx.author.guild_permissions.manage_channels == True or ctx.author.guild_permissions.administrator == True:
			overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
			overwrite.send_messages = True
			await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
			x = reason
			if x == None:
				embed = discord.Embed(title = 'Channel Unlocked :unlock:', description = f'By - {ctx.author.mention} \nReason - None Given', colour = discord.Colour.magenta())
			else:
				embed = discord.Embed(title = 'Channel Unlocked :unlock:', description = f'By - {ctx.author.mention} \nReason - {x}', colour = discord.Colour.magenta())
			await ctx.send(embed=embed)
		else:
			await ctx.reply('You dont have permissions')

	@commands.command(name='role', brief = 'Add/Remove a role', description = 'If the person has the role, it removes it. If they don\'t then it adds it', aliases = ['r'])
	async def role(self, ctx, member:discord.User=None, role=None):
		if member == None:
			await ctx.reply('Please mention who to give/take the role from.')
			return
		if role == None:
			await ctx.reply('Which Role to give?')
			return
		roles = str(list(ctx.guild.roles))
		print(roles)
		role2g = get_close_matches(role, roles)
		role = discord.utils.get(ctx.guild.roles, name = role2g[0])
		if discord.utils.get(member.roles, name = role2g[0]) != None:
			await member.add_roles(role)
			await ctx.reply(f'Added **{role.name}** to **{member.name}**')
		else:
			await member.remove_roles(role)
			await ctx.reply(f'Removed **{role.name}** from **{member.name}**')

	@commands.command(name='mute', brief = 'Mutes Someone', description = 'Adds the muted role to the mentioned user', aliases = ['m'])
	async def mute(self, ctx, member:discord.User=None, no_time = None, *, reason=None):
		if member == None:
			await ctx.reply('Can\'t mute yourself')
			return
		if ctx.author.top_role < member.top_role:
			await ctx.reply('You can only mute Members below you.')
			return
		if no_time == None:
			muterole = discord.utils.get(ctx.guild.roles, name = '・Muted')
			await member.add_roles(muterole)
			await ctx.reply(f'Muted **{member.name}** with reason **{reason}**')
			await member.send(f'You were Muted in Peaky Dankers for Reason: **{reason}**')
			return
		else:
			muterole = discord.utils.get(ctx.guild.roles, name = '・Muted')
			await member.add_roles(muterole)
			if 's' in no_time:
				t = no_time.strip('s')
				t = int(t)
				f_time = int(t)

			elif 'h' in no_time:
				t = no_time.strip('h')
				t = int(t)
				f_time = int(t * 3600)

			elif 'm' in no_time:
				t = no_time.strip('m')
				t = int(t)
				f_time = int(t * 60)
			else:
				f_time = int(t)
			await ctx.reply(f'Muted **{member.name}** with reason **{reason}**')
			await member.send(f'You were Muted in Peaky Dankers for {f_time} seconds with Reason: **{reason}**')
			await asyncio.sleep(f_time)
			await member.remove_roles(muterole)

	@commands.command(name='unmute', brief = 'Unmutes a muted person', description = 'Unmutes a mentioned person.', aliases = ['um'])
	async def unmute(self, ctx, user:discord.User=None):
		if user == None:
			await ctx.reply('Mention a muted person to unmute.')
			return
		if discord.utils.get(user.roles, name = '・Muted') is None:
			await ctx.reply('This Person is not Muted.')
			return
		if ctx.author.top_role < user.top_role:
			await ctx.reply('Can only unmute people below you.')
			return
		muterole = discord.utils.get(ctx.guild.roles, name = '・Muted')
		await user.remove_roles(muterole)

	@commands.command(name='kick', brief = 'Kicks a mentioned person.', description = 'Kicks a person in the server [must be lower than you]', aliases = ['k'])
	async def kick(self, ctx, person:discord.User=None, *, reason=None):
		if ctx.author.guild_permissions.kick_members != True:
			await ctx.reply('You don\'t have the `Kick Members` Permission')
			return
		if person == None:
			await ctx.send('Can\'t kick yourself')
			return
		if ctx.author.top_role < person.top_role:
			await ctx.reply('Cannot do this action due to role hierarchy.\nThis person is higher than you.')
			return
		try:
			await ctx.guild.kick(person, reason=reason)
			embed=discord.Embed(title = f"Kicked {person.name}", description = f'Reason - {reason}\nModerator: {ctx.author.name}', colour=discord.Color.red())
			embed.set_thumbnail(url = person.avatar_url)
			await ctx.send(embed=embed)
		except:
			await ctx.reply('**Error:**\nThis user is higher than me in the role hierarchy.')
			return

	@commands.command(name='ban', brief = 'Bans a person', description = 'Bans a mentioned person [must be lower than you in the hierarchy]', aliases = ['b', 'hammer'])
	async def ban(self, ctx, person:discord.User=None, *, reason=None):
		if ctx.author.guild_permissions.ban_members != True:
			await ctx.reply('You don\'t have the `Ban Members` Permission')
			return
		if person == None:
			await ctx.send('Can\'t ban yourself')
			return
		if ctx.author.top_role < person.top_role:
			await ctx.reply('Cannot do this action due to role hierarchy.\nThis person is higher than you.')
			return
		else:
			try:
				await ctx.guild.ban(person, reason=reason)
				embed=discord.Embed(title = f"Banned {person.name}", description = f'Reason - {reason}\nModerator: {ctx.author.name}', colour=discord.Color.red())
				embed.set_thumbnail(url = person.avatar_url)
				await ctx.send(embed=embed)
			except:
				await ctx.reply('**Error:**\nThis user is higher than me in the role hierarchy.')
				return

def setup(bot):
    bot.add_cog(moderator(bot))