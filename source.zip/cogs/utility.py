import discord, json, random, asyncio
from discord.ext import commands

bot = commands.Bot(command_prefix = '-')

class utility(commands.Cog, name='Utility'):
	def __init__(self, bot):
		self.bot = bot

	@commands.command(name='slowmode', brief = 'Toggles Slowmode', description = 'Sets/Removes the Slowmode of a channel\nMake sure to mention to remove it or in seconds/minutes/hours\nE.g. 2s/2m/2h', aliases = ['sm'])
	async def slowmode(self, ctx, no_time):
		if ctx.author.guild_permissions.manage_channels == True:
			if 'remove' in no_time or no_time == '0':
				await ctx.channel.edit(slowmode_delay=0)
				await ctx.channel.send(f'The Slowmode has been removed.')
			elif 's' in no_time:
				t = no_time.strip('s')
				t = int(t)
				f_time = int(t)
				if t == 0:
					await ctx.send(f'The Slowmode has been removed.')
				else:
					await ctx.send(f'The Slowmode is now {t} seconds.')

			elif 'h' in no_time:
				t = no_time.strip('h')
				t = int(t)
				f_time = int(t * 3600)
				await ctx.send(f'The Slowmode is now {t} hours.')

			elif 'm' in no_time:
				t = no_time.strip('m')
				t = int(t)
				f_time = int(t * 60)
				await ctx.send(f'The Slowmode is now {t} minutes.') 
			if f_time > 21600:
				await ctx.reply('Cant set slowmode beyond 6 hours.')
				return
			await ctx.channel.edit(slowmode_delay=f_time)
		else:
			await ctx.delete()
			return

	@commands.command(name='purge', brief = 'Purges messages', description = 'Purges the given number of messages', aliases = ['p'])
	async def purge(self, ctx, lim):
		if ctx.author.guild_permissions.manage_messages == True:
			if lim == 'all':
				lim = 100
			lim = int(lim)
			if lim < 1:
				await ctx.delete()
				await ctx.channel.send(f'Mhmm. Pretty sure i can\'t purge less than 1 messages {ctx.author.mention}.')
			else:
				await ctx.channel.purge(limit=lim+1)
				x = await ctx.channel.send(f'Purged **{lim}** messages')
				await asyncio.sleep(3)
				await x.delete()
		else:
			await ctx.delete()
			return

	@commands.command(name = "warn", brief = "Warns a user", description = "Warns a user, only used by moderators")
	async def warn(self, ctx):
		pass

	@commands.command(name='afk', brief = 'Sets an AFK for you', description = 'Sets an AFK so that whenever you are pinged an embed pops up dispaying your afk message')
	async def afk(self, ctx, action=None, *, afk_msg=None):
		user = ctx.author
		with open("afk.json", "r") as f:
			users = json.load(f)

		def open_afk(user):
			with open("afk.json", "r") as f:
				users = json.load(f)
			if str(user.id) in users:
				return False
			else:
				users[str(user.id)] = {}
				users[str(user.id)]["afk_status"] = False
				users[str(user.id)]["afk_msg"] = None
			with open("afk.json", "w") as f:
				json.dump(users, f)
			return True
		if afk_msg == None:
			afk_msg = 'Just AFK'
		open_afk(ctx.author)
		if action == 'set':
			users[str(user.id)]["afk_status"] = True
			users[str(user.id)]["afk_msg"] = afk_msg
			with open("afk.json", "w") as f:
				json.dump(users, f)
			embed=discord.Embed(title = 'Set Your AFK', description = afk_msg, color = discord.Color.magenta())
			embed.set_thumbnail(url = user.avatar_url)
			await ctx.send(embed=embed)
		elif action == 'edit':
			if users[str(user.id)]["afk_status"] != True:
				await ctx.reply('You don\'t have an AFK set\nSet it using `-afk set <afk>')
				return
			users[str(user.id)]["afk_msg"] = afk_msg
			with open("afk.json", "w") as f:
				json.dump(users, f)
			embed=discord.Embed(title = 'Edited Your AFK', description = afk_msg, color = discord.Color.magenta())
			embed.set_thumbnail(url = user.avatar_url)
			await ctx.send(embed=embed)
		elif action == 'remove':
			if users[str(user.id)]["afk_status"] != True:
				await ctx.reply('You don\'t have an AFK set\nSet it using `-afk set <afk>')
				return
			users[str(user.id)]["afk_status"] = False
			users[str(user.id)]["afk_msg"] = None
			with open("afk.json", "w") as f:
				json.dump(users, f)
			embed=discord.Embed(title = 'Your AFK has been Removed', color = discord.Color.magenta())
			embed.set_thumbnail(url = user.avatar_url)
			await ctx.send(embed=embed)
		else:
			await ctx.reply('Please provide an action.\nTo set an AFK, `-afk set <afk>`\nTo edit an AFK, `-afk edit <new_afk>`\nTo remove an AFK `-afk remove`')

def setup(bot):
    bot.add_cog(utility(bot))