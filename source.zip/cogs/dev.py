import discord, random
from discord.ext import commands
import os


bot = commands.Bot(command_prefix = '-')

class developer(commands.Cog, name='Developer'):
	def __init__(self, bot):
		self.bot = bot

	@commands.command(name='ping', brief = 'Gives the latency', description = 'Gives the latency in milliseconds', aliases = ['latency'])
	async def ping(self, ctx):
		embed=discord.Embed(title = "My Current Latency Is", description = f"{round(self.bot.latency*1000)} ms", color = discord.Color.magenta())
		await ctx.send(embed=embed)

	@commands.command(name='logout', brief = 'Logs the bot out', description = 'Logs the bot out in case of a malfunction.\nSimilar to you logging out of your account', aliases = ['die'])
	async def logout(self, ctx):
		devs = ['775198018441838642', '750755612505407530', '746904488396324864']
		if str(ctx.author.id) not in devs:
			await ctx.reply(f'Only **The Devs** can log me out.\nCurrent Devs are <@{devs[0]}>, <@{devs[1]}>, <@{devs[2]}>')
			return
		embed=discord.Embed(title = "Logged Out", description = f"With Latency {round(self.bot.latency*1000)}", color = discord.Color.red())
		await ctx.send(embed=embed)
		await os.system("python main.py")

	@commands.command(name = "login")
	async def login(self, ctx):
		await ctx.send("You're already logged in dummy")

def setup(bot):
    bot.add_cog(developer(bot))